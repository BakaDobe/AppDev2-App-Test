package com.example.basketballapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView t1, t2;
    Button b1, b2, b3, b4, b5, b6, b7, b8;
    int val1;
    int val2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);
        t1 = findViewById(R.id.textView5);
        t2 = findViewById(R.id.textView6);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 += 3;
                t1.setText(String.valueOf(val1));
                }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 += 2;
                t1.setText(String.valueOf(val1));
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 += 1;
                t1.setText(String.valueOf(val1));
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val2 += 3;
                t2.setText(String.valueOf(val2));
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val2 += 2;
                t2.setText(String.valueOf(val2));
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val2 += 1;
                t2.setText(String.valueOf(val2));
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(val1 < val2){
                    Toast.makeText(MainActivity.this, "Team B won", Toast.LENGTH_LONG).show();
                }else if (val2 < val1) {
                    Toast.makeText(MainActivity.this, "Team A won", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Draw", Toast.LENGTH_SHORT).show();
                }
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                val1 = 0;
                val2 = 0;
                t1.setText(String.valueOf(val1));
                t2.setText(String.valueOf(val2));
            }
        });
    }
}